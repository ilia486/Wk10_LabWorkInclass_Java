// Copy this file into the src folder ONLY if your project is the class-style "JavaFX project"
// (the sample Wk10JavaFx project has a module-info.java like this one).
// Change the module name to match your project name.
module Wk10_Lab_IliaKiaei {
	requires javafx.controls;
	requires java.sql;
	requires javafx.graphics;

	opens application to javafx.graphics;
}
