-- Wk10 Lab - Employment Application database script
-- MySQL Workbench: File > Open SQL Script, select this file, click the lightning bolt (Execute).
-- Terminal:        mysql -u root -p < database.sql

CREATE DATABASE IF NOT EXISTS employment_db;
USE employment_db;

CREATE TABLE IF NOT EXISTS employment_application (
    id                    INT AUTO_INCREMENT PRIMARY KEY,
    full_name             VARCHAR(100)  NOT NULL,
    current_address       VARCHAR(255)  NOT NULL,
    contact_number        VARCHAR(30)   NOT NULL,
    email_address         VARCHAR(100)  NOT NULL,
    highest_education     VARCHAR(100)  NOT NULL,
    gender                VARCHAR(20)   NOT NULL,
    date_available        DATE          NOT NULL,
    desired_position      VARCHAR(100)  NOT NULL,
    desired_salary        DECIMAL(10,2) NOT NULL,
    legally_authorized    VARCHAR(3)    NOT NULL,   -- Yes / No
    has_relatives         VARCHAR(3)    NOT NULL,   -- Yes / No
    relatives_explanation VARCHAR(255)  NULL,       -- only filled when has_relatives = Yes
    applicant_signature   VARCHAR(100)  NOT NULL,
    submitted_at          TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Use this query after you click Submit (take your screenshot of the result):
-- SELECT * FROM employment_application;
