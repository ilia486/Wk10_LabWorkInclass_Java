package application;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.SQLException;
import java.time.LocalDate;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextField;
import javafx.scene.control.Toggle;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

/**
 * Employment Application form (JavaFX + JDBC with PreparedStatement).
 * The Submit button validates the form and inserts one row into employment_db.employment_application.
 */
public class Main extends Application {

	private final ApplicantDao applicantDao = new ApplicantDao();

	// form controls
	private TextField fullNameField;
	private TextField addressField;
	private TextField contactField;
	private TextField emailField;
	private TextField educationField;
	private ToggleGroup genderGroup;
	private DatePicker dateAvailablePicker;
	private TextField positionField;
	private TextField salaryField;
	private ToggleGroup authorizedGroup;
	private ToggleGroup relativesGroup;
	private TextField explainField;
	private TextField signatureField;

	@Override
	public void start(Stage primaryStage) {

		// ---------- header ----------
		Label company = new Label("John Company");
		company.setFont(Font.font("Tahoma", FontWeight.BOLD, 16));
		Label title = new Label("Employment Application");
		title.setFont(Font.font("Tahoma", FontWeight.BOLD, 26));
		title.setStyle("-fx-text-fill: white;");
		HBox titleBox = new HBox(title);
		titleBox.setPadding(new Insets(12, 20, 12, 20));
		titleBox.setStyle("-fx-background-color: black;");
		HBox.setHgrow(titleBox, Priority.ALWAYS);
		HBox header = new HBox(20, company, titleBox);
		header.setAlignment(Pos.CENTER_LEFT);

		// ---------- form fields ----------
		fullNameField = new TextField();
		addressField = new TextField();
		contactField = new TextField();
		emailField = new TextField();
		educationField = new TextField();
		genderGroup = new ToggleGroup();
		HBox genderBox = createRadioRow(genderGroup, "Male", "Female", "Other");

		dateAvailablePicker = new DatePicker();
		dateAvailablePicker.setPromptText("mm/dd/yyyy");
		positionField = new TextField();
		salaryField = new TextField();
		salaryField.setPromptText("e.g. 55000");
		authorizedGroup = new ToggleGroup();
		HBox authorizedBox = createRadioRow(authorizedGroup, "Yes", "No");
		relativesGroup = new ToggleGroup();
		HBox relativesBox = createRadioRow(relativesGroup, "Yes", "No");
		explainField = new TextField();
		explainField.setDisable(true);               // only used when "relatives" = Yes
		signatureField = new TextField();

		// the explanation field is only enabled when the answer is "Yes"
		relativesGroup.selectedToggleProperty().addListener((obs, oldToggle, newToggle) -> {
			boolean yes = newToggle != null && "Yes".equals(((RadioButton) newToggle).getText());
			explainField.setDisable(!yes);
			if (!yes) {
				explainField.clear();
			}
		});

		// ---------- layout (GridPane like the sample project) ----------
		GridPane grid = new GridPane();
		grid.setHgap(12);
		grid.setVgap(12);
		grid.setPadding(new Insets(10, 25, 25, 25));

		int row = 0;
		grid.add(createSectionLabel("Personal Information"), 0, row++, 2, 1);
		row = addRow(grid, row, "Full Name", fullNameField);
		row = addRow(grid, row, "Current Address", addressField);
		row = addRow(grid, row, "Contact Number", contactField);
		row = addRow(grid, row, "Email Address", emailField);
		row = addRow(grid, row, "Highest Educational Attainment", educationField);
		row = addRow(grid, row, "Gender", genderBox);

		grid.add(createSectionLabel("Employment Eligibility"), 0, row++, 2, 1);
		row = addRow(grid, row, "Date Available", dateAvailablePicker);
		row = addRow(grid, row, "Desired Position", positionField);
		row = addRow(grid, row, "Desired Salary", salaryField);
		row = addRow(grid, row, "Are you legally authorized to work in the country?", authorizedBox);
		row = addRow(grid, row, "Do you have relatives working for our company?", relativesBox);
		row = addRow(grid, row, "If yes, please explain further", explainField);

		Label agreement = new Label("By submitting this application, you agree to adhere to company policies "
				+ "and provide accurate information throughout the employment process.");
		agreement.setWrapText(true);
		agreement.setMaxWidth(560);
		grid.add(agreement, 0, row++, 2, 1);
		row = addRow(grid, row, "Applicant's Signature", signatureField);

		Button submitButton = new Button("Submit");
		submitButton.setPrefWidth(120);
		HBox buttonBox = new HBox(submitButton);
		buttonBox.setAlignment(Pos.BOTTOM_RIGHT);
		grid.add(buttonBox, 1, row);

		submitButton.setOnAction(actionEvent -> handleSubmit());

		VBox root = new VBox(10, header, grid);
		root.setPadding(new Insets(15));
		ScrollPane scrollPane = new ScrollPane(root);
		scrollPane.setFitToWidth(true);

		primaryStage.setTitle("Employment Application");
		primaryStage.setScene(new Scene(scrollPane, 820, 780));
		primaryStage.show();
	}

	// ==================================================================
	//  Submit: validate -> build the object -> PreparedStatement insert
	// ==================================================================
	private void handleSubmit() {
		String error = validateForm();
		if (error != null) {
			showAlert("Error", error, AlertType.ERROR);
			return;
		}

		Applicant applicant = createApplicantObject();
		try {
			int applicantId = applicantDao.saveApplicant(applicant);
			if (applicantId > 0) {
				showAlert("Save", "Application submitted successfully! (ID " + applicantId + ")",
						AlertType.INFORMATION);
				clearForm();
			} else {
				showAlert("Error", "Failed!", AlertType.ERROR);
			}
		} catch (SQLException ex) {
			System.out.println("Exception occured");
			System.out.println(ex.getMessage());
			System.out.println(ex.getErrorCode());
			System.out.println(ex.getSQLState());
			showAlert("Database Error", "The application could not be saved:\n" + ex.getMessage(),
					AlertType.ERROR);
		}
	}

	/** Returns the first error found, or null when the form is valid. */
	private String validateForm() {
		if (isBlank(fullNameField.getText())) {
			return "Full Name is required.";
		}
		if (isBlank(addressField.getText())) {
			return "Current Address is required.";
		}
		if (isBlank(contactField.getText())) {
			return "Contact Number is required.";
		}
		if (!isValidPhone(contactField.getText())) {
			return "Contact Number must have 7 to 15 digits.";
		}
		if (isBlank(emailField.getText())) {
			return "Email Address is required.";
		}
		if (!emailField.getText().trim().matches("[^@\\s]+@[^@\\s]+\\.[^@\\s]+")) {
			return "Please enter a valid email address.";
		}
		if (isBlank(educationField.getText())) {
			return "Highest Educational Attainment is required.";
		}
		if (genderGroup.getSelectedToggle() == null) {
			return "Please select a gender.";
		}
		if (dateAvailablePicker.getValue() == null) {
			return "Date Available is required.";
		}
		if (isBlank(positionField.getText())) {
			return "Desired Position is required.";
		}
		if (isBlank(salaryField.getText())) {
			return "Desired Salary is required.";
		}
		if (parseSalary(salaryField.getText()) == null) {
			return "Desired Salary must be a number between 0 and 99,999,999.99.";
		}
		if (authorizedGroup.getSelectedToggle() == null) {
			return "Please answer: are you legally authorized to work in the country?";
		}
		if (relativesGroup.getSelectedToggle() == null) {
			return "Please answer: do you have relatives working for our company?";
		}
		if ("Yes".equals(selectedText(relativesGroup)) && isBlank(explainField.getText())) {
			return "Please explain your relatives working for the company.";
		}
		if (isBlank(signatureField.getText())) {
			return "Applicant's Signature is required.";
		}
		return null;   // valid
	}

	private Applicant createApplicantObject() {
		Applicant applicant = new Applicant();
		applicant.setFullName(fullNameField.getText().trim());
		applicant.setCurrentAddress(addressField.getText().trim());
		applicant.setContactNumber(contactField.getText().trim());
		applicant.setEmailAddress(emailField.getText().trim());
		applicant.setHighestEducation(educationField.getText().trim());
		applicant.setGender(selectedText(genderGroup));
		applicant.setDateAvailable(dateAvailablePicker.getValue());
		applicant.setDesiredPosition(positionField.getText().trim());
		applicant.setDesiredSalary(parseSalary(salaryField.getText()));
		applicant.setLegallyAuthorized(selectedText(authorizedGroup));
		applicant.setHasRelatives(selectedText(relativesGroup));
		applicant.setRelativesExplanation(explainField.getText().trim());
		applicant.setApplicantSignature(signatureField.getText().trim());
		return applicant;
	}

	private void clearForm() {
		fullNameField.clear();
		addressField.clear();
		contactField.clear();
		emailField.clear();
		educationField.clear();
		genderGroup.selectToggle(null);
		dateAvailablePicker.setValue(null);
		positionField.clear();
		salaryField.clear();
		authorizedGroup.selectToggle(null);
		relativesGroup.selectToggle(null);   // this also clears and disables the explanation field
		explainField.clear();
		signatureField.clear();
	}

	// ==================================================================
	//  Helpers
	// ==================================================================

	/** Protected so that it can be replaced when the application is tested. */
	protected void showAlert(String title, String message, AlertType alertType) {
		Alert alert = new Alert(alertType);
		alert.setTitle(title);
		alert.setHeaderText(null);
		alert.setContentText(message);
		alert.showAndWait();
	}

	private boolean isBlank(String text) {
		return text == null || text.trim().isEmpty();
	}

	private boolean isValidPhone(String phone) {
		String trimmed = phone.trim();
		if (!trimmed.matches("\\+?[0-9 ()\\-]+")) {
			return false;
		}
		int digits = trimmed.replaceAll("\\D", "").length();
		return digits >= 7 && digits <= 15;
	}

	/** "$55,000" or "55000.5" -> 55000.50. Returns null if the text is not a valid salary. */
	private BigDecimal parseSalary(String text) {
		try {
			BigDecimal salary = new BigDecimal(text.trim().replace("$", "").replace(",", ""));
			if (salary.signum() < 0 || salary.compareTo(new BigDecimal("99999999.99")) > 0) {
				return null;
			}
			return salary.setScale(2, RoundingMode.HALF_UP);
		} catch (NumberFormatException e) {
			return null;
		}
	}

	private String selectedText(ToggleGroup group) {
		Toggle selected = group.getSelectedToggle();
		return selected == null ? null : ((RadioButton) selected).getText();
	}

	private int addRow(GridPane grid, int row, String labelText, javafx.scene.Node control) {
		Label label = new Label(labelText);
		label.setWrapText(true);
		label.setMaxWidth(260);
		label.setMinWidth(260);
		grid.add(label, 0, row);
		grid.add(control, 1, row);
		GridPane.setHgrow(control, Priority.ALWAYS);
		if (control instanceof TextField) {
			((TextField) control).setPrefWidth(320);
		}
		return row + 1;
	}

	private Label createSectionLabel(String text) {
		Label label = new Label(text);
		label.setFont(Font.font("Tahoma", FontWeight.BOLD, 14));
		label.setStyle("-fx-background-color: black; -fx-text-fill: white;");
		label.setPadding(new Insets(5, 14, 5, 14));
		return label;
	}

	private HBox createRadioRow(ToggleGroup group, String... options) {
		HBox box = new HBox(18);
		for (String option : options) {
			RadioButton radio = new RadioButton(option);
			radio.setToggleGroup(group);
			box.getChildren().add(radio);
		}
		return box;
	}

	public static void main(String[] args) {
		launch(args);
	}
}
