package application;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;

/** All SQL of the application. Only PreparedStatement is used (values are bound with ?). */
public class ApplicantDao {

	private static final String INSERT_SQL = "INSERT INTO employment_application "
			+ "(full_name, current_address, contact_number, email_address, highest_education, gender, "
			+ "date_available, desired_position, desired_salary, legally_authorized, has_relatives, "
			+ "relatives_explanation, applicant_signature) "
			+ "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

	/** Inserts one application and returns the generated id (0 if nothing was saved). */
	public int saveApplicant(Applicant applicant) throws SQLException {
		// try-with-resources closes the connection, statement and result set automatically
		try (Connection connection = Database.getDBConnection();
				PreparedStatement statement = connection.prepareStatement(INSERT_SQL,
						Statement.RETURN_GENERATED_KEYS)) {

			int counter = 1;
			statement.setString(counter++, applicant.getFullName());
			statement.setString(counter++, applicant.getCurrentAddress());
			statement.setString(counter++, applicant.getContactNumber());
			statement.setString(counter++, applicant.getEmailAddress());
			statement.setString(counter++, applicant.getHighestEducation());
			statement.setString(counter++, applicant.getGender());
			statement.setDate(counter++, Date.valueOf(applicant.getDateAvailable()));
			statement.setString(counter++, applicant.getDesiredPosition());
			statement.setBigDecimal(counter++, applicant.getDesiredSalary());
			statement.setString(counter++, applicant.getLegallyAuthorized());
			statement.setString(counter++, applicant.getHasRelatives());

			String explanation = applicant.getRelativesExplanation();
			if (explanation == null || explanation.trim().isEmpty()) {
				statement.setNull(counter++, Types.VARCHAR);     // stored as NULL in the database
			} else {
				statement.setString(counter++, explanation);
			}
			statement.setString(counter++, applicant.getApplicantSignature());

			statement.executeUpdate();

			try (ResultSet keys = statement.getGeneratedKeys()) {
				if (keys.next()) {
					return keys.getInt(1);
				}
			}
		}
		return 0;
	}
}
