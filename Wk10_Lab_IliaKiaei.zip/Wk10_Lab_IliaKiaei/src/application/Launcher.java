package application;

import javafx.application.Application;

/**
 * Only needed when JavaFX comes from Maven / the classpath (not for the class's e(fx)clipse-style project):
 * run THIS class instead of Main to avoid the "JavaFX runtime components are missing" error.
 */
public class Launcher {

	public static void main(String[] args) {
		Application.launch(Main.class, args);
	}
}
