package application;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Opens connections to MySQL.
 * >>> Change DB_PASSWORD (and DB_USER if needed) to match YOUR MySQL installation. <<<
 */
public class Database {

	private static final String DB_DRIVER = "com.mysql.cj.jdbc.Driver";
	private static final String DB_CONNECTION = System.getProperty("employment.db.url",
			"jdbc:mysql://localhost:3306/employment_db");
	private static final String DB_USER = System.getProperty("employment.db.user", "root");
	private static final String DB_PASSWORD = System.getProperty("employment.db.password", "your_password_here");

	private Database() {
	}

	/** Returns a new connection. The caller must close it. Problems are reported as SQLException. */
	public static Connection getDBConnection() throws SQLException {
		try {
			Class.forName(DB_DRIVER);
		} catch (ClassNotFoundException exception) {
			// DriverManager may still find the driver by itself; if not, getConnection reports the problem
		}
		return DriverManager.getConnection(DB_CONNECTION, DB_USER, DB_PASSWORD);
	}
}
